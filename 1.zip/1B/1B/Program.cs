﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1B
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int numberOfRows = 5;
            int n = 1;
            for (int i = 1;i <= numberOfRows;i++)
            {
                for (int j = 1; j <= i; j++)
                {
                    Console.Write((n++) + " ");
                }
                Console.WriteLine();
            }
            Console.ReadKey();
        }
    }
}
