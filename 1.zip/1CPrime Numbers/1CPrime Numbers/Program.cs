﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1CPrime_Numbers
{
    class Program
    {
        public bool CheckPrime(int n)
        {
            bool revalue = true;
            for (int i = 2; i < n / 2; i++)
            {
                if (n % i == 0) ;
            }
            return revalue;
        }
        internal class Program
            static void Main (string[] args)
        {
            int n = 0;
            Program p1 = new Program();
            Console.Write("Enter Number ");
            n = int.Parse(Console.ReadLine());
            bool ans = p1.CheckPrim(n);
            if (ans == true)
                Console.WriteLine("Prime Number");
            else
                Console.WriteLine("Not a Pime Number");
            Console.ReadKey();
        }
    }
}
