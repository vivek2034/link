﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Services;
using System.Text;
using System.Threading.Tasks;

namespace _1A
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num1, num2, prod, sum, sub, div ;
            Console.Write("enter number 1 :");
            num1=Int32.Parse(Console.ReadLine());
            Console.Write("enter number 2 :");
            num2=Convert.ToInt32(Console.ReadLine());
            prod = num1 * num2;
            sum = num1 + num2;
            sub = num1 - num2;
            div = num1 / num2;
            Console.WriteLine(num1 + "*" + num2 + "=" + prod);
            Console.WriteLine(num1 + "+" + num2 + "=" + sum);
            Console.WriteLine(num1 + "-" + num2 + "=" + sub);
            Console.WriteLine(num1 + "/" + num2 + "=" + div);
            Console.ReadKey();

        }
    }
}