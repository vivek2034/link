﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1C
{
    class Program
    {
        public void GenerateFibo(int n)
        {
            int no = 0;
            int no1 = 1;
            Console.WriteLine(no + "\n" + no1);

            for (int i = 3; i <= n; i++)
            {
                int no3 = no + no1;
                Console.WriteLine(no3);
                no = no1;
                no1 = no3;
            }

        }
    }
    internal class Prog
    {
        static void Main(string[] args)
        {
            Program p1 = new Program();
            Console.WriteLine("How many numbers in FIbo series");
            int n = int.Parse(Console.ReadLine());
            p1.GenerateFibo(n);
            Console.ReadKey();
        }
    }
}
