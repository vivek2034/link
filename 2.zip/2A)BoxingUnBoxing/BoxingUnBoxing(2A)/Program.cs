﻿using System;
using
System.Collections.Generic;
using
System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prac2a
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num = 100;
            Object boxed = num;
            Console.WriteLine("Boxed value: " + boxed);
            int unboxed = (int)boxed;
            Console.WriteLine("Unboxed value: " + unboxed);

            num = 200;
            Console.WriteLine("Origanal valaue after modification: " + num);
            Console.WriteLine("Boxed value remain unchanged: " + boxed);

            Console.ReadKey();
        }
    }
}