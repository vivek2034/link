﻿using System;
using
System.Collections.Generic;
using
System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prac2c
{
    interface abc
    {
        void Adding(int x, int y);
    }
    interface bcd
    {
        void show();
    }

    class Test : abc, bcd
    {
        public void Adding(int a, int b)
        {
            Console.WriteLine("Addition is: " + (a + b));
        }
        public void show()
        {
            Console.WriteLine("show of test from abc");
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            abc a1;
            a1 = new Test();
            a1.Adding(10, 10);
            bcd b1 = (bcd)a1;
            b1.show();
            Console.ReadKey();
        }
    }
}
